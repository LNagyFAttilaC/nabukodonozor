package nabukodonozor;

public interface InteractWithTower {
	//interakcio BasicTower-rel
	public void act(BasicTower b);
}
