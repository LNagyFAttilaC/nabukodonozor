package nabukodonozor;

public class BasicDetector extends Detector {
	//a tornyot egybol csatolo konstruktor
	public BasicDetector(Tower t) {
		super(t);
	}
}