package nabukodonozor;

public interface Active {
	//teendok minden utemben
	public void tick();
}
