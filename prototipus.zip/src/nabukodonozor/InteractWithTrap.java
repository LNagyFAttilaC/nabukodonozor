package nabukodonozor;

public interface InteractWithTrap {
	//interakcio BasicTrap-pel
	public void act(BasicTrap b);
}
